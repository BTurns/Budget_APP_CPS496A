package lonie1gr.cps496.cmich.edu.ourapp;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class UpdateSavings extends AppCompatActivity {
    EditText update;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_savings);

        update = (EditText) (findViewById(R.id.updateAmount));

    }

    public void plusClick(View v) {
        Intent returnIntent = new Intent();

        String text = update.getText().toString();
        try {
            double value = Double.parseDouble(text);
            returnIntent.putExtra("value", value);
            setResult(Activity.RESULT_OK, returnIntent);
            finish();
        } catch (NumberFormatException e) {

        }




    }

    public void minusClick(View v) {
        Intent returnIntent = new Intent();

        String text = update.getText().toString();
        try {
            double value = Double.parseDouble(update.getText().toString());
            value = 0 - value;

            returnIntent.putExtra("value", value);
            setResult(Activity.RESULT_OK, returnIntent);
            finish();
        } catch (NumberFormatException e) {

        }
    }
}
